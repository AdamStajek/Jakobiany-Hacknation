"""WodoStrażnik parcel water analysis."""
